import json

class categories:
 def _categories():
 
  Categories= [
    {"name": "قنوات مباشر المرئية", "url": "قنوات ","img":"https://tinyurl.com/26lvwexw"},
    {"name": "الإذاعة ", "url": "الإذاعة","img":"https://tinyurl.com/23c538ct"}, 
  ]
  return Categories
 
 

   
  