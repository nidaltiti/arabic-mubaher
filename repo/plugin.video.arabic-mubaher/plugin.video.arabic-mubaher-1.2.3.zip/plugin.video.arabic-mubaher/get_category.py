import json

class categories:
 def _categories():
 
  Categories= [
    {"name": "قنوات مباشر المرئية", "url": "قنوات ","img":"https://cdn.discordapp.com/attachments/1065105718962823178/1092386430304653352/a21d7030-c89d-48db-a934-c3671aa2ca1e.jpg"},
    {"name": "الإذاعة ", "url": "الإذاعة","img":"https://cdn.discordapp.com/attachments/1065105718962823178/1092387734699651162/d5416c17-ed87-4334-acb3-a8776309d5fc.jpg"}, 
  ]
  return Categories
 
 

   
  